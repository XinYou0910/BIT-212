/*
	Database Creation Script for the cafe database
*/
DROP DATABASE IF EXISTS CAFE;

CREATE DATABASE CAFE;

USE CAFE;

/* Create PRODUCT_GROUP table. */

CREATE TABLE productgroup (
  product_group INT(3) NOT NULL PRIMARY KEY,
  product_group_name VARCHAR(25) NOT NULL DEFAULT ''
  );

/* INSERT initialization data into the PRODUCT_GROUP table. */

INSERT INTO productgroup (product_group, product_group_name) VALUES
	(1, 'Cake')
	, (2, 'Drinks'),
  (3, 'Dishes')
  ,(4,'Others');

/* Create PRODUCT table. */

CREATE TABLE product (
  id INT(3) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  product_name VARCHAR(40) NOT NULL DEFAULT '',
  description VARCHAR(200) NOT NULL DEFAULT '',
  price DECIMAL(10,2) NOT NULL DEFAULT 0.0,
  product_group INT(2) NOT NULL DEFAULT 1,
  image_url VARCHAR(256) DEFAULT 'images/default-image.jpg',
  FOREIGN KEY (product_group) REFERENCES productgroup (product_group)
  );

/* INSERT initialization data into the PRODUCT table. */

INSERT INTO product (product_name, description, price, product_group, image_url) VALUES
	  ('Black Forest', 'Fresh, fruity, and chocolaty... Simply irresistible!', 13.50, 1, 'images/black_forest.jpeg')
	, ('Choco Banana', 'We have more than half-a-dozen flavors!', 15.00, 1, 'images/choco_banana.png')
	, ('Vanila Cake', 'Made with Madagascar vanilla with a sweet scent of frostings', 22.50, 1, 'images/vanila.jpg')
	, ('Araibata Spagetti', 'Pasta in classic Italian tomato sauce.', 15.50, 3, 'images/araibata_spagetti.png')
	, ('Marcaroni and cheese', 'Bursting with flavor, featuring a secret homemade mac & cheese sauce.', 12.50, 3, 'images/marcaroni.jpeg')
  , ('Bolongnese', 'Crafted with creamy Swiss cheese and premium imported pasta', 16.50, 3, 'images/bolognese.png')
	, ('Coffee', 'Freshly brewed black or expertly blended Ethiopian coffee.', 6.00, 2, 'images/coffee.png')
	, ('Tea', 'Smooth and flavorful red tea from the misty hills of Sri Lanka.', 5.00, 2, 'images/tea.png')
	, ('Strawberry Smoothie', 'Strawberry smoothie with the fresh strawberries', 8.50, 2, 'images/strawberry.png');

/* Create ORDER table. */

CREATE TABLE ordertable(
  order_number INT(5) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  order_date_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0.0
  );

/* Create ORDER_ITEM table. */

CREATE TABLE order_item (
  order_number INT(5) NOT NULL,
  order_item_number INT(5) NOT NULL,
  product_id INT(3),
  quantity INT(2),
  amount DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (order_number, order_item_number),
  FOREIGN KEY (order_number) REFERENCES ordertable(order_number),
  FOREIGN KEY (product_id) REFERENCES product (id)
  );
